﻿//'******************************************************************************************************************************
//' CLASS NAME:   WriteLogTxt
//' DESCRIPTION:  To write log to text file .
//' DATE:         11-MAR-2015
//' AUTHOR:       MANIND AGARWAL
//' COPYRIGHT @   2015,TCS
//' COMMENTS:
//' REVISION HISTORY:
//'----------------------------------------------------------------------------------------------------------------------------
//'CR/SDR No.      Date          Changed By                   Description                                          Reviewed By   
//'
//'-----------------------------------------------------------------------------------------------------------------------------
//'*****************************************************************************************************************************


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.VisualBasic;

namespace LogWriter
{
    public class WriteLogTxt
    {

        string sLogPath { get; set; }

        public WriteLogTxt(string sPath,string sFileName)
        {

            if (!Directory.Exists(sPath))
            {
                Directory.CreateDirectory(sPath);
            }

            sLogPath = sPath+sFileName;
        }


        public void subPrepareLog(string sIndicator, string rstrBuffer)
        {
            try
            {
                if (sIndicator == "")
                {
                    using (StreamWriter sWriter = File.AppendText(sLogPath))
                    {
                        sWriter.Write(System.Environment.NewLine + "Log Entry : ");
                        sWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString());
                        sWriter.WriteLine(" :");
                        sWriter.WriteLine(" :{0}", rstrBuffer);
                        sWriter.Flush();
                        sWriter.Close();
                    }
                }
                //else if (sIndicator == "E")
                //{
                //    using (StreamWriter sWriter = File.AppendText(sLogPath))
                //    {
                //        sWriter.Write(System.Environment.NewLine + "Error Entry : ");
                //        sWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString());
                //        sWriter.WriteLine(" :");
                //        sWriter.WriteLine(" :{0}", rstrBuffer);
                //        sWriter.Flush();
                //        sWriter.Close();
                //    }
                //    File.AppendAllText(sCAError, "Error File For StagingDigitalSign\\Signed : " + DateTime.Now.ToString() + System.Environment.NewLine);
                //}
            }
            catch (Exception ex)
            {
            }
        }


    }
}
