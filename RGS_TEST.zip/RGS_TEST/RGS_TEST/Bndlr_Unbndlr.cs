﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Data;

namespace RGS
{

    public class Bndlr_Unbndlr
    {
        private DataTable dtbLevel2DataHolder = new DataTable();

        public DataTable Unbndlr(string Msg)
        {
            string tempData;
            dtbLevel2DataHolder.Clear();
            dtbLevel2DataHolder.Reset();
            




            dtbLevel2DataHolder.Columns.Add("Data");

            do
            {
                tempData = Msg.Substring(0,Msg.IndexOf("~"));
                DataRow r = dtbLevel2DataHolder.NewRow();
                if (tempData == "$") 
                {
                    break;
                }
                r["Data"] = tempData;

                dtbLevel2DataHolder.Rows.Add(r);
                Msg = Msg.Substring(Msg.IndexOf("~") + 1);

            } while (Msg.Length>2);

            return dtbLevel2DataHolder;





        }


        public Bndlr_Unbndlr()
        {
        }
    }


    }



    
