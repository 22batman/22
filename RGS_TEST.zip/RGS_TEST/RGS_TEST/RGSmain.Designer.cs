﻿namespace RGS
{
    partial class RGSmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StsLblMQCnctnSts = new System.Windows.Forms.ToolStripStatusLabel();
            this.StsLblMQCnctn = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.StsPB = new System.Windows.Forms.ToolStripProgressBar();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabMain = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnStrt = new System.Windows.Forms.Button();
            this.tabLog = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.txtPUT = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnWriteMsg = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lblConnect = new System.Windows.Forms.Label();
            this.txtPUTQueueName = new System.Windows.Forms.TextBox();
            this.gbStats = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtMsgFailed = new System.Windows.Forms.TextBox();
            this.txtMsgInQ = new System.Windows.Forms.TextBox();
            this.txtMsgPrcsd = new System.Windows.Forms.TextBox();
            this.lblMsgFailed = new System.Windows.Forms.Label();
            this.lblMsgPndng = new System.Windows.Forms.Label();
            this.lblMsgPrcsd = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtPswd = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPswd = new System.Windows.Forms.Label();
            this.statusStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabLog.SuspendLayout();
            this.gbStats.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.AutoSize = false;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StsLblMQCnctnSts,
            this.StsLblMQCnctn,
            this.toolStripStatusLabel1,
            this.StsPB});
            this.statusStrip1.Location = new System.Drawing.Point(0, 306);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.statusStrip1.Size = new System.Drawing.Size(624, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 31;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StsLblMQCnctnSts
            // 
            this.StsLblMQCnctnSts.AutoSize = false;
            this.StsLblMQCnctnSts.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.StsLblMQCnctnSts.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.StsLblMQCnctnSts.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.StsLblMQCnctnSts.Name = "StsLblMQCnctnSts";
            this.StsLblMQCnctnSts.Size = new System.Drawing.Size(130, 17);
            this.StsLblMQCnctnSts.Text = "MQ Connection Status : ";
            this.StsLblMQCnctnSts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // StsLblMQCnctn
            // 
            this.StsLblMQCnctn.AutoSize = false;
            this.StsLblMQCnctn.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.StsLblMQCnctn.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedInner;
            this.StsLblMQCnctn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.StsLblMQCnctn.Name = "StsLblMQCnctn";
            this.StsLblMQCnctn.Size = new System.Drawing.Size(100, 17);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(139, 17);
            this.toolStripStatusLabel1.Text = "Current Message Process";
            // 
            // StsPB
            // 
            this.StsPB.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.StsPB.AutoSize = false;
            this.StsPB.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.StsPB.Maximum = 0;
            this.StsPB.Name = "StsPB";
            this.StsPB.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StsPB.Size = new System.Drawing.Size(250, 16);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabMain);
            this.tabControl1.Controls.Add(this.tabLog);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(624, 235);
            this.tabControl1.TabIndex = 33;
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.lblPswd);
            this.tabMain.Controls.Add(this.lblUsername);
            this.tabMain.Controls.Add(this.txtPswd);
            this.tabMain.Controls.Add(this.txtUserName);
            this.tabMain.Controls.Add(this.label3);
            this.tabMain.Controls.Add(this.label2);
            this.tabMain.Controls.Add(this.button3);
            this.tabMain.Controls.Add(this.button2);
            this.tabMain.Controls.Add(this.label1);
            this.tabMain.Controls.Add(this.comboBox1);
            this.tabMain.Controls.Add(this.btnStrt);
            this.tabMain.Location = new System.Drawing.Point(4, 24);
            this.tabMain.Name = "tabMain";
            this.tabMain.Padding = new System.Windows.Forms.Padding(3);
            this.tabMain.Size = new System.Drawing.Size(616, 207);
            this.tabMain.TabIndex = 0;
            this.tabMain.Text = "Main";
            this.tabMain.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(155, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 15);
            this.label3.TabIndex = 44;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(155, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 15);
            this.label2.TabIndex = 43;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(8, 169);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(131, 23);
            this.button3.TabIndex = 42;
            this.button3.Text = "Select Destination";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(8, 131);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(131, 23);
            this.button2.TabIndex = 41;
            this.button2.Text = "Select Soure";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 15);
            this.label1.TabIndex = 40;
            this.label1.Text = "SYSTEM";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(79, 53);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(155, 23);
            this.comboBox1.TabIndex = 39;
            // 
            // btnStrt
            // 
            this.btnStrt.Location = new System.Drawing.Point(262, 53);
            this.btnStrt.Name = "btnStrt";
            this.btnStrt.Size = new System.Drawing.Size(75, 23);
            this.btnStrt.TabIndex = 38;
            this.btnStrt.Text = "Start";
            this.btnStrt.UseVisualStyleBackColor = true;
            this.btnStrt.Click += new System.EventHandler(this.btnStrt_Click);
            // 
            // tabLog
            // 
            this.tabLog.Controls.Add(this.richTextBox1);
            this.tabLog.Controls.Add(this.txtPUT);
            this.tabLog.Controls.Add(this.btnConnect);
            this.tabLog.Controls.Add(this.btnWriteMsg);
            this.tabLog.Controls.Add(this.label5);
            this.tabLog.Controls.Add(this.lblConnect);
            this.tabLog.Controls.Add(this.txtPUTQueueName);
            this.tabLog.Location = new System.Drawing.Point(4, 24);
            this.tabLog.Name = "tabLog";
            this.tabLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabLog.Size = new System.Drawing.Size(616, 207);
            this.tabLog.TabIndex = 1;
            this.tabLog.Text = "Log";
            this.tabLog.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.richTextBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBox1.Location = new System.Drawing.Point(9, 7);
            this.richTextBox1.MaxLength = 1999999999;
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBox1.Size = new System.Drawing.Size(338, 196);
            this.richTextBox1.TabIndex = 37;
            this.richTextBox1.Text = "";
            // 
            // txtPUT
            // 
            this.txtPUT.Location = new System.Drawing.Point(380, 6);
            this.txtPUT.MaxLength = 999999999;
            this.txtPUT.Multiline = true;
            this.txtPUT.Name = "txtPUT";
            this.txtPUT.Size = new System.Drawing.Size(195, 45);
            this.txtPUT.TabIndex = 34;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(353, 57);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 31;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnWriteMsg
            // 
            this.btnWriteMsg.Location = new System.Drawing.Point(464, 60);
            this.btnWriteMsg.Name = "btnWriteMsg";
            this.btnWriteMsg.Size = new System.Drawing.Size(75, 23);
            this.btnWriteMsg.TabIndex = 36;
            this.btnWriteMsg.Text = "Write Msg";
            this.btnWriteMsg.UseVisualStyleBackColor = true;
            this.btnWriteMsg.Click += new System.EventHandler(this.btnWriteMsg_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(453, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 15);
            this.label5.TabIndex = 35;
            this.label5.Text = "Q to Send Name";
            // 
            // lblConnect
            // 
            this.lblConnect.AutoSize = true;
            this.lblConnect.Location = new System.Drawing.Point(485, 138);
            this.lblConnect.Name = "lblConnect";
            this.lblConnect.Size = new System.Drawing.Size(0, 15);
            this.lblConnect.TabIndex = 32;
            // 
            // txtPUTQueueName
            // 
            this.txtPUTQueueName.Location = new System.Drawing.Point(353, 89);
            this.txtPUTQueueName.Name = "txtPUTQueueName";
            this.txtPUTQueueName.Size = new System.Drawing.Size(218, 21);
            this.txtPUTQueueName.TabIndex = 33;
            // 
            // gbStats
            // 
            this.gbStats.Controls.Add(this.button1);
            this.gbStats.Controls.Add(this.txtMsgFailed);
            this.gbStats.Controls.Add(this.txtMsgInQ);
            this.gbStats.Controls.Add(this.txtMsgPrcsd);
            this.gbStats.Controls.Add(this.lblMsgFailed);
            this.gbStats.Controls.Add(this.lblMsgPndng);
            this.gbStats.Controls.Add(this.lblMsgPrcsd);
            this.gbStats.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gbStats.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbStats.Location = new System.Drawing.Point(0, 231);
            this.gbStats.Name = "gbStats";
            this.gbStats.Size = new System.Drawing.Size(624, 75);
            this.gbStats.TabIndex = 34;
            this.gbStats.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(384, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(191, 23);
            this.button1.TabIndex = 39;
            this.button1.Text = "View Failed Message Details";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // txtMsgFailed
            // 
            this.txtMsgFailed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMsgFailed.Location = new System.Drawing.Point(523, 19);
            this.txtMsgFailed.Name = "txtMsgFailed";
            this.txtMsgFailed.Size = new System.Drawing.Size(52, 21);
            this.txtMsgFailed.TabIndex = 5;
            this.txtMsgFailed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMsgInQ
            // 
            this.txtMsgInQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMsgInQ.Location = new System.Drawing.Point(208, 44);
            this.txtMsgInQ.Name = "txtMsgInQ";
            this.txtMsgInQ.Size = new System.Drawing.Size(52, 21);
            this.txtMsgInQ.TabIndex = 4;
            this.txtMsgInQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMsgPrcsd
            // 
            this.txtMsgPrcsd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMsgPrcsd.Location = new System.Drawing.Point(208, 19);
            this.txtMsgPrcsd.Name = "txtMsgPrcsd";
            this.txtMsgPrcsd.Size = new System.Drawing.Size(52, 21);
            this.txtMsgPrcsd.TabIndex = 3;
            this.txtMsgPrcsd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMsgFailed
            // 
            this.lblMsgFailed.AutoSize = true;
            this.lblMsgFailed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgFailed.Location = new System.Drawing.Point(381, 22);
            this.lblMsgFailed.Name = "lblMsgFailed";
            this.lblMsgFailed.Size = new System.Drawing.Size(136, 15);
            this.lblMsgFailed.TabIndex = 2;
            this.lblMsgFailed.Text = "No. of Messages Failed";
            // 
            // lblMsgPndng
            // 
            this.lblMsgPndng.AutoSize = true;
            this.lblMsgPndng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgPndng.Location = new System.Drawing.Point(42, 47);
            this.lblMsgPndng.Name = "lblMsgPndng";
            this.lblMsgPndng.Size = new System.Drawing.Size(152, 15);
            this.lblMsgPndng.TabIndex = 1;
            this.lblMsgPndng.Text = "No. of Messages in Queue";
            // 
            // lblMsgPrcsd
            // 
            this.lblMsgPrcsd.AutoSize = true;
            this.lblMsgPrcsd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsgPrcsd.Location = new System.Drawing.Point(42, 22);
            this.lblMsgPrcsd.Name = "lblMsgPrcsd";
            this.lblMsgPrcsd.Size = new System.Drawing.Size(160, 15);
            this.lblMsgPrcsd.TabIndex = 0;
            this.lblMsgPrcsd.Text = "No. of Messages Processed";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(510, 6);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(100, 21);
            this.txtUserName.TabIndex = 45;
            // 
            // txtPswd
            // 
            this.txtPswd.Location = new System.Drawing.Point(510, 34);
            this.txtPswd.Name = "txtPswd";
            this.txtPswd.Size = new System.Drawing.Size(100, 21);
            this.txtPswd.TabIndex = 46;
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(437, 9);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(67, 15);
            this.lblUsername.TabIndex = 47;
            this.lblUsername.Text = "UserName";
            // 
            // lblPswd
            // 
            this.lblPswd.AutoSize = true;
            this.lblPswd.Location = new System.Drawing.Point(437, 37);
            this.lblPswd.Name = "lblPswd";
            this.lblPswd.Size = new System.Drawing.Size(61, 15);
            this.lblPswd.TabIndex = 48;
            this.lblPswd.Text = "Password";
            // 
            // RGSmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 328);
            this.Controls.Add(this.gbStats);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "RGSmain";
            this.Text = "Form1";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            this.tabMain.PerformLayout();
            this.tabLog.ResumeLayout(false);
            this.tabLog.PerformLayout();
            this.gbStats.ResumeLayout(false);
            this.gbStats.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StsLblMQCnctnSts;
        private System.Windows.Forms.ToolStripStatusLabel StsLblMQCnctn;
        private System.Windows.Forms.ToolStripProgressBar StsPB;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabMain;
        private System.Windows.Forms.TabPage tabLog;
        private System.Windows.Forms.TextBox txtPUT;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnWriteMsg;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblConnect;
        private System.Windows.Forms.TextBox txtPUTQueueName;
        private System.Windows.Forms.Button btnStrt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox gbStats;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtMsgFailed;
        private System.Windows.Forms.TextBox txtMsgInQ;
        private System.Windows.Forms.TextBox txtMsgPrcsd;
        private System.Windows.Forms.Label lblMsgFailed;
        private System.Windows.Forms.Label lblMsgPndng;
        private System.Windows.Forms.Label lblMsgPrcsd;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblPswd;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox txtPswd;
        private System.Windows.Forms.TextBox txtUserName;
    }
}

