﻿//'******************************************************************************************************************************
//' CLASS NAME:   RGSMain
//' DESCRIPTION:  Main form of RGS .
//' DATE:         11-MAR-2015
//' AUTHOR:       MANIND AGARWAL
//' COPYRIGHT @   2015,TCS
//' COMMENTS:
//' REVISION HISTORY:
//'----------------------------------------------------------------------------------------------------------------------------
//'CR/SDR No.      Date          Changed By                   Description                                          Reviewed By   
//'
//'-----------------------------------------------------------------------------------------------------------------------------
//'*****************************************************************************************************************************

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Globalization;

using MQ;
using MessageProcessor;

using Microsoft.VisualBasic;

namespace RGS
{
    [ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260",
    false)]
     
    public partial class RGSmain : Form
    {
        Task Task1;
        Unbndlr UnBndlMsg = new Unbndlr();
        DataTable dtbLvl2Data;
        ArrayList aLvl1Data;
        string sErrMsg;
        Thread Thrd_PollingMQ;

        bool bMQPoll,bStartFlag;

        string QueueManagerName;
        string SenderQueueName;
        string RecieverQueueName;
        string ChannelInfo;
        string sMQmsg;
        string[] sMsg;
        int iPrcsMsgCount;
        int intInputQueueDepth;
        string Source_Path;
        string Destination_Path;
        string ServiceName, UserName, Password;



        MQProcessor accessMQ = new MQProcessor();
        
        public RGSmain()
        {
            InitializeComponent();
            //QueueManagerName = System.Configuration.ConfigurationManager.AppSettings["RGS_MQ_ManagerName"].ToString();
            //SenderQueueName = System.Configuration.ConfigurationManager.AppSettings["RGS_MQ_Name"].ToString();
            //RecieverQueueName = System.Configuration.ConfigurationManager.AppSettings["RGS_MQ_Name"].ToString();
            //ChannelInfo = System.Configuration.ConfigurationManager.AppSettings["RGS_MQ_ChannelName"].ToString();

            iPrcsMsgCount = 0;

            StsLblMQCnctnSts.Text = "MQ Connection Status : ";
            
            txtMsgPrcsd.Text = iPrcsMsgCount.ToString();
        }

        private void btnStrt_Click(object sender, EventArgs e)
        {

            //MessageBox.Show(Environment.ProcessorCount.ToString());
            if (btnStrt.Text == "Start")
            {
                UserName = txtUserName.Text.Trim();
                Password = txtPswd.Text.Trim();


                btnStrt.Text = "Stop";
                bStartFlag = true;
                bMQPoll = true;
                //StsLblMQCnctn.Text = accessMQ.ConnectMQ("", ChannelInfo);
                Thrd_PollingMQ = new Thread(new ThreadStart(PollMQ));
                Thrd_PollingMQ.Start();
            }
            else if (btnStrt.Text == "Stop")
            {
                btnStrt.Text = "Start";
                bStartFlag = false;
            }

        }

        private void PollMQ() 
        {
             while (bMQPoll && bStartFlag)
                {
                 //sMQmsg = accessMQ.ReadQMsg(RecieverQueueName, out intInputQueueDepth);
                 sMQmsg = txtPUT.Text;
                 subUpdateQueueDepthCnt(intInputQueueDepth);
   
                    if (sMQmsg != string.Empty)
                    {
                        bMQPoll = false;
                        char[] cSplitChar = { '#' };
                        sMsg = sMQmsg.Split(cSplitChar, 2);
                        bool result =  UnBndlMsg.UnbundleMsg(sMsg[0],sMsg[1], out aLvl1Data, out dtbLvl2Data);
                        if (result)
                        {
                            dtbLvl2Data.Rows.RemoveAt(dtbLvl2Data.Rows.Count - 1);
                            //rpt_export pdfExport = new rpt_export(aLvl1Data, dtbLvl2Data, @"D:\PROD_imp\", @"D:\PROD_imp\RPRT\", "CCILN", "CCIL", "YsQgAJ6o", this);
                            rpt_export pdfExport = new rpt_export(aLvl1Data, dtbLvl2Data, Source_Path, Destination_Path, "CCILN", UserName, Password, this);
                            ParallelOptions options = new ParallelOptions();
                            //options.MaxDegreeOfParallelism = 1;//Environment.ProcessorCount;
                            options.MaxDegreeOfParallelism = Environment.ProcessorCount;
                            //SetPBMaxValue(dtbLvl2Data.Rows.Count);
                            subUpdateQueueDepthCnt(intInputQueueDepth-1);
                            Task1 = Task.Factory.StartNew(() =>
                            {

                                Parallel.For(0, dtbLvl2Data.Rows.Count, options, i =>
                                {
                                    pdfExport.exportPdf(i);

                                });

                                return true;

                            });

                            Task continuationTask = Task1.ContinueWith((b) =>
                            {

                                bMQPoll = false;
                                //iPrcsMsgCount++;
                                //subUpdatePrcsMsgCnt(iPrcsMsgCount);

                            });
                            continuationTask.Wait();
                        }
                        else
                        {
                            bMQPoll = true;
                        }
                    }
                    else
                    {
                        Thread.Sleep(2000);
                        bMQPoll = true;
               
                    }
            }
        }





        private void subUpdateQueueDepthCnt(int iQueueDepth)
        {
            if (txtMsgInQ.InvokeRequired)
            {
                txtMsgInQ.Invoke
                    (new MethodInvoker
                        (delegate
                                {
                                  txtMsgInQ.Text = iQueueDepth.ToString();
                                  txtMsgInQ.Text = txtMsgInQ.Text.PadRight(2);
                                }
                        )
                     );
            }
            else
            {
                txtMsgInQ.Text = iQueueDepth.ToString();
                txtMsgInQ.Text = txtMsgInQ.Text.PadRight(2);
            }





            //if (statusStrip1.InvokeRequired)
            //{
            //    statusStrip1.Invoke(new MethodInvoker(delegate
            //    {
            //        ((ToolStripStatusLabel)(statusStrip1.Items["StsLblMsgMQCnt"])).Text = iQueueDepth.ToString();

            //    }
            //            ));
            //}
            //else
            //{
            //    ((ToolStripStatusLabel)(statusStrip1.Items["StsLblMsgMQCnt"])).Text = iQueueDepth.ToString();
            //}
        }

        private void subUpdatePrcsMsgCnt(int iCnt)
        {
            if (txtMsgPrcsd.InvokeRequired)
            {
                txtMsgPrcsd.Invoke
                    (new MethodInvoker
                        (delegate
                        {
                            txtMsgPrcsd.Text = iCnt.ToString();
                            txtMsgPrcsd.Text = txtMsgPrcsd.Text.PadRight(2);
                        }
                        )
                     );
            }
            else
            {
                txtMsgPrcsd.Text = iCnt.ToString();
                txtMsgPrcsd.Text = txtMsgPrcsd.Text.PadRight(2);
            }

        }



 
        private void btnConnect_Click(object sender, EventArgs e)
        {
           txtPUT.Text = "";

            lblConnect.Text = accessMQ.ConnectMQ("", ChannelInfo);
        }

        private void btnWriteMsg_Click(object sender, EventArgs e)
        {
            txtPUT.Text = accessMQ.WriteLocalQMsg(txtPUT.Text.ToString(),
                SenderQueueName);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD1 = new FolderBrowserDialog();
            FBD1.ShowDialog();
            Source_Path = FBD1.SelectedPath.ToString() + @"\";
            label2.Text = Source_Path;
            //MessageBox.Show(Source_Path);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD1 = new FolderBrowserDialog();
            FBD1.ShowDialog();
            Destination_Path = FBD1.SelectedPath.ToString() + @"\";
            label3.Text = Destination_Path;
            //MessageBox.Show(Destination_Path);
        }

     

        
       
       

   
        

        
        

    }

    [ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260",
    false)]
    public class PBUpdate
    {
        Form form1;
        RGSmain rgs = new RGSmain();

        public PBUpdate(Form Frm)
        {
            form1 = Frm;

        }
    

        public void SetPBValue(int Val)
        {

            if (form1.Controls["PB"].InvokeRequired)
            {
                form1.Controls["PB"].Invoke(new MethodInvoker(delegate { ((ProgressBar)form1.Controls["PB"]).Value = Val; }));
            }
            else
            {
                ((ProgressBar)form1.Controls["PB"]).Value = Val+1;
            }

            //if (StsPB.GetCurrentParent().InvokeRequired)
            //{
            //    StsPB.GetCurrentParent().Invoke(new MethodInvoker(delegate { StsPB.Value = Val; }));
            //}
            //else
            //{
            //    StsPB.Value = Val;
            //}

        }


        public void SetPBMaxValue(int Val)
        {
            try
            {

                //if (form1.Controls["PB"].InvokeRequired)
                //{
                //    form1.Controls["PB"].Invoke(new MethodInvoker(delegate 
                //        { 
                //            ((ProgressBar)form1.Controls["PB"]).Minimum = 0;
                //            ((ProgressBar)form1.Controls["PB"]).Maximum = Val;
                //            ((ProgressBar)form1.Controls["PB"]).Value = 0; 
                //        }
                //        ));
                //}
                //else
                //{
                //    ((ProgressBar)rgs.Controls["PB"]).Minimum = 0;
                //    ((ProgressBar)rgs.Controls["PB"]).Maximum = Val;
                //    ((ProgressBar)form1.Controls["PB"]).Value = 0;
                //}


                if (form1.Controls["statusStrip1"].InvokeRequired)
                {


                    form1.Controls["statusStrip1"].Invoke(new MethodInvoker(delegate 
                        { 
                            ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Minimum = 0;
                            ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Maximum = Val;
                            ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Value = 0;
                        }
                        ));
                }
                else
                {
                    ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Minimum = 0;
                    ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Maximum = Val;
                    ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Value=0;
                }
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message);
            }
        }




        public void SetNewPBValue()
        {

            //if (form1.Controls["PB"].InvokeRequired)
            //{
            //    form1.Controls["PB"].Invoke(new MethodInvoker(delegate { ((ProgressBar)form1.Controls["PB"]).Value = ((ProgressBar)form1.Controls["PB"]).Value + 1; }));
            //}
            //else
            //{
            //    ((ProgressBar)form1.Controls["PB"]).Value = ((ProgressBar)form1.Controls["PB"]).Value + 1;
            //}

            if (form1.Controls["statusStrip1"].InvokeRequired)
            {
                form1.Controls["statusStrip1"].Invoke(new MethodInvoker(delegate { ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Value = ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Value + 1; }));
            }
            else
            {
                ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Value = ((ToolStripProgressBar)((StatusStrip)form1.Controls["statusStrip1"]).Items["stsPB"]).Value + 1;
            }

        }



    }
}
