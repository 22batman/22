﻿//'******************************************************************************************************************************
//' CLASS NAME:   rpt_export
//' DESCRIPTION:  Used for Export .
//' DATE:         11-MAR-2015
//' AUTHOR:       MANIND AGARWAL
//' COPYRIGHT @   2015,TCS
//' COMMENTS:
//' REVISION HISTORY:
//'----------------------------------------------------------------------------------------------------------------------------
//'CR/SDR No.      Date          Changed By                   Description                                          Reviewed By   
//'
//'-----------------------------------------------------------------------------------------------------------------------------
//'*****************************************************************************************************************************



using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OracleClient;
using System.Threading;
using System.Threading.Tasks;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Globalization;
using System.Data;
using LogWriter;
using System.Windows.Forms;



namespace RGS
{
    [ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260",
    false)]

    class rpt_export
    {

        string sSrcePath { get; set; }
        string sDstnPath { get; set; }
        string sRprtIdntfr { get; set; }
        string sServerName { get; set; }
        string sUserID { get; set; }
        string sPassword { get; set; }
        DataTable dtbRprtPrmStruct { get; set; }
        DataTable dtbRprtPrm { get; set; }
        PBUpdate updatePBBar;
        ReportDocument RptDcmnt;//Added temp

        WriteLogTxt wrtTxtLog;

        public rpt_export(ArrayList aLvl1Data, DataTable dtbLvl2Data, string sPDFSrcePath, string sPDFDStnPath, string sSrvrName,string sUsrID, string sPswd,Form f1)
        {
            try
            {
                updatePBBar = new PBUpdate(f1);
                sServerName = sSrvrName;
                sUserID = sUsrID;
                sPassword = sPswd;
                string sLoggingPath = AppDomain.CurrentDomain.BaseDirectory + @"LOGS\Logs\A_" ;

                wrtTxtLog = new WriteLogTxt(sLoggingPath, DateTime.Now.ToString("dd-MMM-yy") + ".txt");
                
                sSrcePath = sPDFSrcePath;
                sDstnPath = sPDFDStnPath;
                sRprtIdntfr = aLvl1Data[1].ToString();
                dtbRprtPrm = dtbLvl2Data;
                string sConnString = "PASSWORD=UATDMTRGS;USER ID=UATDMTRGS;DATA SOURCE=CCIL";
                OracleConnection conn = new OracleConnection(sConnString);

                StringBuilder sSqlMsgStrct = new StringBuilder();

                sSqlMsgStrct.Clear();
                sSqlMsgStrct.Append(" SELECT ");
                sSqlMsgStrct.Append(" RPRM_RPRT_IDTY, ");
                sSqlMsgStrct.Append(" RPRM_RPRT_PARM_SRNO, ");
                sSqlMsgStrct.Append(" RPRM_PARM_DATA_TYPE ");
                sSqlMsgStrct.Append(" FROM RPRM ");
                sSqlMsgStrct.Append(" WHERE ");
                sSqlMsgStrct.Append(" RPRM_RPRT_IDTY = '");
                sSqlMsgStrct.Append(sRprtIdntfr);
                sSqlMsgStrct.Append("'");
                sSqlMsgStrct.Append(" ORDER BY ");
                sSqlMsgStrct.Append("RPRM_RPRT_PARM_SRNO");

                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sSqlMsgStrct.ToString();

                OracleDataAdapter da = new OracleDataAdapter(cmd);
                dtbRprtPrmStruct = new DataTable();
                da.Fill(dtbRprtPrmStruct);
                conn.Close();
                //updatePBBar.SetPBMaxValue(dtbLvl2Data.Rows.Count);




                //Added temp

                RptDcmnt = new ReportDocument();

                RptDcmnt.Load(sSrcePath + sRprtIdntfr + ".rpt");
                TableLogOnInfos crtableLogoninfos = new TableLogOnInfos();
                TableLogOnInfo crtableLogoninfo = new TableLogOnInfo();
                ConnectionInfo crConnectionInfo = new ConnectionInfo();
                Tables CrTables;

                RptDcmnt.DataSourceConnections.Clear();
                crConnectionInfo.ServerName = sServerName;
                //crConnectionInfo.DatabaseName = "DEVMCMCSS";//"";
                crConnectionInfo.UserID = sUserID;
                crConnectionInfo.Password = sPassword;


                CrTables = RptDcmnt.Database.Tables; 



                foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
                {
                    crtableLogoninfo = CrTable.LogOnInfo;
                    crtableLogoninfo.ConnectionInfo = crConnectionInfo;
                    CrTable.ApplyLogOnInfo(crtableLogoninfo);

                }



                //Ended temp


            }
            catch (Exception ex)
            {
                wrtTxtLog.subPrepareLog("", ex.StackTrace);
            }

        }

        public void exportPdf(int i)
        {
            
            char[] cSplit1Char = { '#' };
            string[] sTemp = dtbRprtPrm.Rows[i][0].ToString().Split(cSplit1Char);
            
            char[] cSplit2Char = { ':' };
            string[] sPrm=sTemp[1].Split(cSplit2Char);

            char[] cSplit3Char = { '?' };
            string[] identifier = sTemp[0].Split(cSplit3Char); 


            if (sPrm.Length != dtbRprtPrmStruct.Rows.Count)
            {


                //raise error/exception
            }




            
            
            // temp commented

           //ReportDocument RptDcmnt = new ReportDocument();

           // RptDcmnt.Load(sSrcePath + sRprtIdntfr + ".rpt");
           // TableLogOnInfos crtableLogoninfos = new TableLogOnInfos();
           // TableLogOnInfo crtableLogoninfo = new TableLogOnInfo();
           // ConnectionInfo crConnectionInfo = new ConnectionInfo();
           // Tables CrTables;

            // temp commented


            try
            {

                // temp commented

                //RptDcmnt.DataSourceConnections.Clear();
                //crConnectionInfo.ServerName = sServerName;                
                ////crConnectionInfo.DatabaseName = "DEVMCMCSS";//"";
                //crConnectionInfo.UserID = sUserID;
                //crConnectionInfo.Password = sPassword;

                // temp commented



                ////////////////////////////////////////////////////////
                //SubreportObject SubRprtObj;//////////////
                //ReportObjects RprtObjs;///////////////
                //Sections CR_Secs;//////////////
                //ReportDocument CR_Sub_Rprt_doc;
                //CR_Secs = RptDcmnt.ReportDefinition.Sections;//////////////////

                //foreach (Section crSection in CR_Secs)
                //{
                //    RprtObjs = crSection.ReportObjects;

                //    foreach (ReportObject crReportObject in RprtObjs)
                //    {
                //        if (crReportObject.Kind == ReportObjectKind.SubreportObject)
                //        {
                //            SubRprtObj = (SubreportObject)crReportObject;

                //            CR_Sub_Rprt_doc = SubRprtObj.OpenSubreport(SubRprtObj.SubreportName);
                            
                //            CrTables = CR_Sub_Rprt_doc.Database.Tables;
                //            CR_Sub_Rprt_doc.DataSourceConnections.Clear();

                //            foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
                //            {
                                
                //                crtableLogoninfo = CrTable.LogOnInfo;
                //                crtableLogoninfo.ConnectionInfo = crConnectionInfo;
                //                CrTable.ApplyLogOnInfo(crtableLogoninfo);

                //            }

                //        }
                //    }

                //}







                ////////////////////////////////////////////////////////


                // temp commented
                //CrTables = RptDcmnt.Database.Tables;



                //foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
                //{
                //    crtableLogoninfo = CrTable.LogOnInfo;
                //    crtableLogoninfo.ConnectionInfo = crConnectionInfo;
                //    CrTable.ApplyLogOnInfo(crtableLogoninfo);
                    
                //}

                // temp commented


                try
                {
                    for (int r = 0; r < dtbRprtPrmStruct.Rows.Count; r++)
                    {
                        string sDataTyp = dtbRprtPrmStruct.Rows[r][2].ToString().ToUpper();
                        switch (sDataTyp)
                        {
                            case "VARCHAR2":
                                RptDcmnt.SetParameterValue(r, sPrm[r]);
                                break;
                            case "DATE":
                                RptDcmnt.SetParameterValue(r, DateTime.ParseExact(sPrm[r], "yyyyMMdd", CultureInfo.InvariantCulture));
                                break;
                            case "NUMBER":
                                RptDcmnt.SetParameterValue(r, Convert.ToInt32(sPrm[r]));
                                break;
                            default:
                                break;

                        }


                    }

                }
                catch (Exception ex)
                {
                    wrtTxtLog.subPrepareLog("", "  Inner   ####   " + ex.StackTrace);
                }


                string sConnString = "PASSWORD=UATDMTTR;USER ID=UATDMTTR;DATA SOURCE=CCIL";
                OracleConnection conn = new OracleConnection(sConnString);

                StringBuilder sSqlMsgStrct = new StringBuilder();

                sSqlMsgStrct.Clear();
                sSqlMsgStrct.Append(" SELECT ");
                sSqlMsgStrct.Append(" RGL_FILE_NAME ");
                //sSqlMsgStrct.Append(" RPRM_RPRT_PARM_SRNO, ");
                //sSqlMsgStrct.Append(" RPRM_PARM_DATA_TYPE ");
                sSqlMsgStrct.Append(" FROM RPRT_GNRTN_LOG ");
                sSqlMsgStrct.Append(" WHERE ");
                sSqlMsgStrct.Append(" RGL_STS = 'GNRTD'");
                sSqlMsgStrct.Append(" AND RGL_GNRTN_DATE = '01-Apr-16'");
                sSqlMsgStrct.Append(" AND RGL_RPM_RPRT_ID  = '");
                sSqlMsgStrct.Append(sRprtIdntfr);
                sSqlMsgStrct.Append("'");
                sSqlMsgStrct.Append(" AND RGL_MBM_MBR_ID  = '");
                sSqlMsgStrct.Append(identifier[1]);
                sSqlMsgStrct.Append("'");
                //sSqlMsgStrct.Append(" ORDER BY ");
                //sSqlMsgStrct.Append("RPRM_RPRT_PARM_SRNO");

                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sSqlMsgStrct.ToString();

                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataTable dtbRprtName = new DataTable();
                da.Fill(dtbRprtName);
                conn.Close();


                dtbRprtName.Rows[0][0].ToString();



                ExportOptions CrExportOptions;
                DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
                PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
                //CrDiskFileDestinationOptions.DiskFileName = sDstnPath  + "tmp" + identifier[0] +"_" +  identifier[1] + "_" + sRprtIdntfr + ".pdf";
                CrDiskFileDestinationOptions.DiskFileName = sDstnPath + "tmp" + identifier[0] + "_" + identifier[1] + "_" + dtbRprtName.Rows[0][0].ToString();



                CrExportOptions = RptDcmnt.ExportOptions;
                {
                    //CharacterSeparatedValuesFormatOptions frm = new CharacterSeparatedValuesFormatOptions();
                    //frm.Delimiter = ",";
    
                    CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                    CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                    //CrExportOptions.ExportFormatOptions = frm;
                    CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
                    CrExportOptions.FormatOptions = CrFormatTypeOptions;
                }

               RptDcmnt.Export();
               //RptDcmnt.Close();
               

               //updatePBBar.SetPBValue(Interlocked.Increment(ref i));
               //updatePBBar.SetNewPBValue();

            }
            catch (Exception ex)
            {
                wrtTxtLog.subPrepareLog("", "Main--StackTrace" + " ####  " + ex.StackTrace + Environment.NewLine + "Main--Message" + " ####  " + ex.Message);
                
            }

        }







        //private void SetLogonInfo_Click(object sender, EventArgs e)
        //{
        //    //rptClientDoc.DatabaseController.SetTableLocationByServerDatabaseName("Xtreme", "192.168.43.128", "TestDB", "sb", "PW");


        //    CrystalDecisions.CrystalReports.Engine.ReportObjects crReportObjects;
        //    CrystalDecisions.CrystalReports.Engine.SubreportObject crSubreportObject;
        //    CrystalDecisions.CrystalReports.Engine.ReportDocument crSubreportDocument;
        //    CrystalDecisions.CrystalReports.Engine.Database crDatabase;
        //    CrystalDecisions.CrystalReports.Engine.Tables crTables;
        //    TableLogOnInfo crTableLogOnInfo;

        //    CrystalDecisions.Shared.ConnectionInfo crConnectioninfo = new CrystalDecisions.Shared.ConnectionInfo();

        //    //pass the necessary parameters to the connectionInfo object
        //    crConnectioninfo.ServerName = "192.168.43.128";
        //    crConnectioninfo.UserID = "sb";
        //    crConnectioninfo.Password = "pw";
        //    crConnectioninfo.DatabaseName = "Xtreme";

        //    //set up the database and tables objects to refer to the current report
        //    //crDatabase = rpt.Database;
        //    crTables = crDatabase.Tables;

        //    //loop through all the tables and pass in the connection info
        //    foreach (CrystalDecisions.CrystalReports.Engine.Table crTable in crTables)
        //    {
        //        crTableLogOnInfo = crTable.LogOnInfo;
        //        crTableLogOnInfo.ConnectionInfo = crConnectioninfo;
        //        crTable.ApplyLogOnInfo(crTableLogOnInfo);
        //    }

        //    //set the crSections object to the current report's sections
        //    CrystalDecisions.CrystalReports.Engine.Sections crSections = rpt.ReportDefinition.Sections;

        //    //loop through all the sections to find all the report objects
        //    foreach (CrystalDecisions.CrystalReports.Engine.Section crSection in crSections)
        //    {
        //        crReportObjects = crSection.ReportObjects;
        //        //loop through all the report objects to find all the subreports
        //        foreach (CrystalDecisions.CrystalReports.Engine.ReportObject crReportObject in crReportObjects)
        //        {
        //            if (crReportObject.Kind == ReportObjectKind.SubreportObject)
        //            {
        //                //you will need to typecast the reportobject to a subreport 
        //                //object once you find it
        //                crSubreportObject = (CrystalDecisions.CrystalReports.Engine.SubreportObject)crReportObject;

        //                //open the subreport object
        //                crSubreportDocument = crSubreportObject.OpenSubreport(crSubreportObject.SubreportName);

        //                //set the database and tables objects to work with the subreport
        //                crDatabase = crSubreportDocument.Database;
        //                crTables = crDatabase.Tables;

        //                //loop through all the tables in the subreport and 
        //                //set up the connection info and apply it to the tables
        //                foreach (CrystalDecisions.CrystalReports.Engine.Table crTable in crTables)
        //                {
        //                    crConnectioninfo.ServerName = "192.168.43.128";
        //                    crConnectioninfo.UserID = "sb";
        //                    crConnectioninfo.Password = "pw";
        //                    crConnectioninfo.DatabaseName = "Xtreme";

        //                    crTableLogOnInfo = crTable.LogOnInfo;
        //                    crTableLogOnInfo.ConnectionInfo = crConnectioninfo;
        //                    crTable.ApplyLogOnInfo(crTableLogOnInfo);
        //                }
        //            }
        //        }
        //    }

        //    //bool myTEst = rptClientDoc.DatabaseController.VerifyTableConnectivity("Orders");

        //    GroupPath gp = new GroupPath();
        //    string tmp = String.Empty;
        //    try
        //    {
        //        rptClientDoc.RowsetController.GetSQLStatement(gp, out tmp);
        //        btnSQLStatement.Text = tmp;
        //    }
        //    catch (Exception ex)
        //    {
        //        btnSQLStatement.Text = "ERROR: " + ex.Message;
        //        return;
        //    }
        //}










    }
}
