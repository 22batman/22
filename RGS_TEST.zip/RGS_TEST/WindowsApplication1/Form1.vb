﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ViewReport("")
    End Sub



    Friend Function ViewReport(ByVal sReportName As String, Optional ByVal sSelectionFormula As String = "", Optional ByVal param As String = "") As Boolean

        Dim intCounter As Integer
        Dim intCounter1 As Integer
        Dim strTableName As String
        '' Dim objReportsParameters As frmReportsParameters
        Dim objReport As New CrystalDecisions.CrystalReports.Engine.ReportDocument
        Dim mySection As CrystalDecisions.CrystalReports.Engine.Section
        Dim mySections As CrystalDecisions.CrystalReports.Engine.Sections


        Dim ConInfo As New CrystalDecisions.Shared.TableLogOnInfo

        Dim paraValue As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim currValue As CrystalDecisions.Shared.ParameterValues
        Dim mySubReportObject As CrystalDecisions.CrystalReports.Engine.SubreportObject
        Dim mySubRepDoc As New CrystalDecisions.CrystalReports.Engine.ReportDocument

        Dim strParamenters As String
        Dim strParValPair() As String
        Dim strVal() As String
        Dim sFileName As String
        Dim index As Integer

        Try
            strParamenters = "CCTRD:CBLO:20150214:CCMFEDEL0282"

            sFileName = "D:\Reports_source\Source\CS2201.rpt"

            objReport.Load(sFileName)

            intCounter = objReport.DataDefinition.ParameterFields.Count
            If intCounter = 1 Then
                If InStr(objReport.DataDefinition.ParameterFields(0).ParameterFieldName, ".", CompareMethod.Text) > 0 Then
                    intCounter = 0
                End If
            End If


            If intCounter > 0 And Trim(param) <> "" Then

                strParValPair = strParamenters.Split(":")
                For index = 0 To UBound(strParValPair)
                    If InStr(strParValPair(index), "=") > 0 Then
                        strVal = strParValPair(index).Split("=")
                        paraValue.Value = strVal(1)
                        currValue = objReport.DataDefinition.ParameterFields(strVal(0)).CurrentValues
                        currValue.Add(paraValue)
                        objReport.DataDefinition.ParameterFields(strVal(0)).ApplyCurrentValues(currValue)
                    End If
                Next
            End If



            ConInfo.ConnectionInfo.UserID = "DEVMCMCSS"
            ConInfo.ConnectionInfo.Password = "DEVMCMCSS"
            ConInfo.ConnectionInfo.ServerName = "CCI139L"
            ConInfo.ConnectionInfo.DatabaseName = "CCI139L"

            For intCounter = 0 To objReport.Database.Tables.Count - 1
                objReport.Database.Tables(intCounter).ApplyLogOnInfo(ConInfo)
            Next



            For index = 0 To objReport.ReportDefinition.Sections.Count - 1
                For intCounter = 0 To objReport.ReportDefinition.Sections(index).ReportObjects.Count - 1
                    With objReport.ReportDefinition.Sections(index)
                        If .ReportObjects(intCounter).Kind = CrystalDecisions.Shared.ReportObjectKind.SubreportObject Then
                            mySubReportObject = CType(.ReportObjects(intCounter), CrystalDecisions.CrystalReports.Engine.SubreportObject)
                            mySubRepDoc = mySubReportObject.OpenSubreport(mySubReportObject.SubreportName)
                            For intCounter1 = 0 To mySubRepDoc.Database.Tables.Count - 1
                                mySubRepDoc.Database.Tables(intCounter1).ApplyLogOnInfo(ConInfo)
                            Next
                        End If
                    End With
                Next
            Next





            If sSelectionFormula.Length > 0 Then
                objReport.RecordSelectionFormula = sSelectionFormula
            End If
            Dim opt As CrystalDecisions.Shared.ExportOptions = New CrystalDecisions.Shared.ExportOptions
            opt.ExportFormatType = CrystalDecisions.Shared.ExportFormatType.PortableDocFormat

            'rptViewer.ReportSource = Nothing
            'rptViewer.ReportSource = objReport
            'rptViewer.Show()

            objReport.Export(opt)
            Application.DoEvents()

            Me.Text = sReportName
            MyBase.Visible = True
            Me.BringToFront()

            Return True

        Catch ex As System.Exception
            MsgBox(ex.Message)
        End Try
    End Function



End Class
