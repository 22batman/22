﻿//'******************************************************************************************************************************
//' CLASS NAME:   Unbndlr
//' DESCRIPTION:  To unbundle the message, Level 1 data and level 2 data .
//' DATE:         11-MAR-2015
//' AUTHOR:       Hemant
//' COPYRIGHT @   2015,TCS
//' COMMENTS:
//' REVISION HISTORY:
//'----------------------------------------------------------------------------------------------------------------------------
//'CR/SDR No.      Date          Changed By                   Description                                          Reviewed By   
//'
//'-----------------------------------------------------------------------------------------------------------------------------
//'*****************************************************************************************************************************


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OracleClient;
using System.Data;
using System.Collections;
using LogWriter;

namespace MessageProcessor
{
    [ObsoleteAttribute("OracleConnection has been deprecated. http://go.microsoft.com/fwlink/?LinkID=144260",
    false)]

    public class Unbndlr
    {
        public DataTable _dtMsgStrct;
        WriteLogTxt wrtTxtLog;

        public Unbndlr()
        {
            string sConnString = "PASSWORD=YsQgAJ6o;USER ID=CCIL;DATA SOURCE=PROD";
            OracleConnection conn = new OracleConnection(sConnString);

            StringBuilder sSqlMsgStrct = new StringBuilder();

            sSqlMsgStrct.Clear();
            sSqlMsgStrct.Append(" SELECT ims.IMS_MSG_TYPE, ");
            sSqlMsgStrct.Append("        ims.IMS_BLK_ID, ");
            sSqlMsgStrct.Append("        ims.IMS_BLK_SEQ_NO, ");
            sSqlMsgStrct.Append("        ims.IMS_FLD_MNDTRY, ");
            sSqlMsgStrct.Append("        ims.IMS_FLD_SEQ_NO ");
            sSqlMsgStrct.Append("       FROM INTRFCE_MSG_STRCT ims ");
            sSqlMsgStrct.Append("   WHERE ims.IMS_MSG_TYPE IN ('7000','7002','7004')");
            sSqlMsgStrct.Append("   ORDER BY ims.IMS_MSG_TYPE, ims.IMS_FLD_SEQ_NO ");

            OracleCommand cmd = new OracleCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = sSqlMsgStrct.ToString();

            OracleDataAdapter da = new OracleDataAdapter(cmd);
            _dtMsgStrct = new DataTable();
            da.Fill(_dtMsgStrct);
            conn.Close();

        }

        public bool UnbundleMsg(string sHeader, string sMsg ,out ArrayList aLvl1Data,out DataTable dtLvl2Data)
        {
            bool bErrFlag = true;
            string sLoggingPath = AppDomain.CurrentDomain.BaseDirectory + @"LOGS\Logs\A_";
            wrtTxtLog = new WriteLogTxt(sLoggingPath, DateTime.Now.ToString("dd-MMM-yy") + ".txt");
            string[] sLvl2Data;
            aLvl1Data = new ArrayList();
            dtLvl2Data= new DataTable();
            dtLvl2Data.Columns.Add("data");
            try
            {
                
                string sStrpdMsg = sMsg;
                string sVal;
                int i = 0;
                int iCrntPos = 0;
                int iTldPos;
                var msgStrct = from myRow in _dtMsgStrct.AsEnumerable()
                               where myRow.Field<string>("IMS_MSG_TYPE").Equals("7002", StringComparison.OrdinalIgnoreCase)
                               select myRow;

                DataTable dtMsgStrct = msgStrct.CopyToDataTable();

                int blkid = Convert.ToInt32(_dtMsgStrct.Rows[0][1].ToString());

                while (blkid == 1)
                {
                    sStrpdMsg = sStrpdMsg.Substring(iCrntPos);
                    iTldPos = sStrpdMsg.IndexOf('~');
                    sVal = sStrpdMsg.Substring(0, iTldPos);
                    if (dtMsgStrct.Rows[i]["IMS_FLD_MNDTRY"].ToString() == "M" && sVal == "")
                    {
                        sMsg =   " for : " + sHeader + "---" + "Field at position" + i + "is a mandatory field and hence can not be blank";
                        throw new Exception(sMsg);
                    }
                    else
                    {
                        aLvl1Data.Add(sVal);
                    }
                    iCrntPos = iTldPos + 1;
                    i++;
                    blkid = Convert.ToInt32(_dtMsgStrct.Rows[i][1].ToString());
                }

                sStrpdMsg = sStrpdMsg.Substring(iCrntPos);
                char[] seprt = {'~','$'};
                sLvl2Data = sStrpdMsg.Split(seprt, StringSplitOptions.RemoveEmptyEntries);
                
                foreach (string element in sLvl2Data)
                {
                    if (element != string.Empty)
                    {
                        DataRow r = dtLvl2Data.NewRow();
                        r["data"] = element;
                        dtLvl2Data.Rows.Add(r);
                    }
                }
                
                
                
            }
            catch (Exception ex)
            {
                bErrFlag = false;
                wrtTxtLog.subPrepareLog("", "UnBNDLR" + " ####  " + ex.StackTrace);
                wrtTxtLog.subPrepareLog("", "UnBNDLR" + " ####  " + ex.Message);
                
            }

            return bErrFlag;
        }
    }
}
