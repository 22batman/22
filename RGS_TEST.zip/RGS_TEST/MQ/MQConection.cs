﻿//'******************************************************************************************************************************
//' CLASS NAME:   MQProcessor
//' DESCRIPTION:  To process data from MQ .
//' DATE:         11-MAR-2015
//' AUTHOR:       MANIND AGARWAL
//' COPYRIGHT @   2015,TCS
//' COMMENTS:
//' REVISION HISTORY:
//'----------------------------------------------------------------------------------------------------------------------------
//'CR/SDR No.      Date          Changed By                   Description                                          Reviewed By   
//'
//'-----------------------------------------------------------------------------------------------------------------------------
//'*****************************************************************************************************************************


using System;
using System.Collections.Generic;
using System.Linq;

using System.Threading.Tasks;

using IBM.WMQ;

namespace MQ
{
    public class MQProcessor
    {
        
    MQQueueManager queueManager;
    MQQueue queue;
    MQMessage queueMessage;
    MQPutMessageOptions queuePutMessageOptions;
    MQGetMessageOptions queueGetMessageOptions;

    static string SendQueueName;
    static string ReceiveQueueName;
    static string QueueManagerName;
    static string ChannelInfo;
    string channelName;
    string transportType;
    string connectionName;
    string message;

    public MQProcessor()
    { 
      
    }

    /// <summary>
    /// Connect to MQ Server
    /// </summary>
    /// <param name="strQueueManagerName">Queue Manager Name</param>
    /// <param name="strChannelInfo">Channel Information</param>
    /// <returns></returns>
    public string ConnectMQ(string strQueueManagerName, string strChannelInfo)
    {
      QueueManagerName = strQueueManagerName;
      ChannelInfo = strChannelInfo;

      char[] separator = { '/' };
      string[] ChannelParams;
      ChannelParams = ChannelInfo.Split(separator);
      channelName = ChannelParams[0];
      transportType = ChannelParams[1];
      connectionName = ChannelParams[2];
      string strReturn = "";

      try
      {
        queueManager = new MQQueueManager(QueueManagerName,
           channelName, connectionName);
        strReturn = "Connected";
      }
      catch (MQException exp)
      {
        strReturn = "Exception: " + exp.Message;
        strReturn = "Not Connected";
      }
      catch (Exception exp)
      {
        strReturn = "Exception: " + exp.Message;
        strReturn = "Not Connected";
      }
      return strReturn;
    }

    /// <summary>
    /// Write Message to Local Queue
    /// </summary>
    /// <param name="strInputMsg">Text Message</param>
    /// <param name="strqueueName">Queue Name</param>
    /// <returns></returns>
    public string WriteLocalQMsg(string strInputMsg, string strQueueName)
    {
      string strReturn = "";
      SendQueueName = strQueueName;
      try
      {
        queue = queueManager.AccessQueue(SendQueueName,
          MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING);
        message = strInputMsg;
        queueMessage = new MQMessage();
        queueMessage.WriteString(message);
        queueMessage.Format = MQC.MQFMT_STRING;
        queuePutMessageOptions = new MQPutMessageOptions();
        queue.Put(queueMessage, queuePutMessageOptions);
        strReturn = "Message sent to the queue successfully";
        queue.Close();
      }
      catch (MQException MQexp)
      {
        strReturn = "Exception: " + MQexp.Message;
      }
      catch (Exception exp)
      {
        strReturn = "Exception: " + exp.Message;
      }
      return strReturn;
    }
    
    /// <summary>
    /// Write Message to Local Queue
    /// </summary>
    /// <param name="strInputMsg">Text Message</param>
    /// <returns></returns>
    public string WriteLocalQMsg(string strInputMsg)
    {
      string strReturn = "";
      try
      {
        queue = queueManager.AccessQueue(SendQueueName,
          MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING );
        message = strInputMsg;
        queueMessage = new MQMessage();
        queueMessage.WriteString(message);
        queueMessage.Format = MQC.MQFMT_STRING;
        queuePutMessageOptions = new MQPutMessageOptions();
        queue.Put( queueMessage, queuePutMessageOptions);
        strReturn = "Message sent to the queue successfully";
        queue.Close();

      }
      catch (MQException MQexp)
      {
        strReturn = "Exception: "+ MQexp.Message;
      }
      catch (Exception exp)
      {
        strReturn = "Exception: "+ exp.Message;
      }
      return strReturn;
    }

    /// <summary>
    /// Read Message from Local Queue
    /// </summary>
    /// <param name="strqueueName">Queue Name</param>
    /// <returns>Text Message</returns>
    public string ReadQMsg(string strQueueName, out int intQueueDepth)
        {
          string strReturn = "";
          ReceiveQueueName = strQueueName;
          try
          {
            queue = queueManager.AccessQueue(ReceiveQueueName,
              MQC.MQOO_INPUT_AS_Q_DEF + MQC.MQOO_FAIL_IF_QUIESCING + MQC.MQOO_INQUIRE);
            queueMessage = new MQMessage();
            queueMessage.Format = MQC.MQFMT_STRING;
            queueGetMessageOptions = new MQGetMessageOptions();
            bool sts = queue.OpenStatus;
            intQueueDepth = queue.CurrentDepth;
            if (intQueueDepth > 0)
            {

                queue.Get(queueMessage, queueGetMessageOptions);
                strReturn = queueMessage.ReadString(queueMessage.MessageLength);
            }
            else
            {
                strReturn = "";
            }
            
            queue.Close();
          }
          catch (MQException MQexp)
          {

            strReturn = "Exception: " + MQexp.Message;
            strReturn = string.Empty;
            intQueueDepth = 0;
          }
          catch (Exception exp)
          {
            strReturn = "Exception: " + exp.Message;
            strReturn = string.Empty;
              intQueueDepth = 0;
          }
          return strReturn;
        }
  }
}

