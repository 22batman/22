﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Data.OleDb;
using System.IO;

using Microsoft.Office.Interop.Excel;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.ReportAppServer.ClientDoc;
using CrystalDecisions.ReportAppServer.Controllers;
using CrystalDecisions.ReportAppServer.DataDefModel;
//using CrystalDecisions.ReportSource;

namespace GetQueriesFromRpt
{
    public partial class Form1 : Form
    {
        string sSrcePath;

        public Form1()
        {
            InitializeComponent();
        }

        #region                 Functions

            public string getCommandTextSubRprt(ReportDocument rd)
        {
            string sql;
            sql = "";
            try
            {
                //if (!rd.IsLoaded)
                //    throw new ArgumentException("Please ensure that the reportDocument has been loaded before being passed to getCommandText");
                PropertyInfo pi = rd.Database.Tables.GetType().GetProperty("RasTables", BindingFlags.NonPublic | BindingFlags.Instance);
                sql = ((dynamic)pi.GetValue(rd.Database.Tables, pi.GetIndexParameters()))[0].CommandText;
                sql = sql.Replace("\n", " ").Replace("\r", " ").Replace("\t", " ").Replace("\\", "");
                sql = sql.Replace("  ", " ").Replace("  ", " ").Replace("  ", " ").Replace("  ", " ");
                return sql;
            }
            catch (Exception ex)
            {
                return "Error";
            }
        }

            public string getCommandTextRprt(ReportDocument rd)
        {
            string sql;
            sql = "";
            try
            {
                foreach (dynamic table in rd.ReportClientDocument.DatabaseController.Database.Tables)
                {
                    if (table.ClassName == "CrystalReports.CommandTable")
                    {
                        string commandSql = table.CommandText;
                        commandSql = commandSql.Replace("\n", " ").Replace("\r", " ").Replace("\t", " ").Replace("\\", "");
                        sql = commandSql.Replace("  ", " ").Replace("  ", " ").Replace("  ", " ").Replace("  ", " ");
                    }
                }
            }
            catch (Exception ex)
            {
                sql = "Error";
            }

            return sql;
        }

        #endregion 

        # region Procedures
          private void chkConnections()
                {
                    btnExport.Visible = false;
                    lblCurrentActivity.Text = "Connection info ";

                    System.Data.DataTable dtbAllConnection;
                    DataRow drRow;
                    dataGridView1.DataSource = null;
                    string sRprtIdntfr;

                    ReportDocument RptDcmnt;
                    ReportDocument rdSubRprt;
                    TableLogOnInfo crtableLogoninfo;
                    CrystalDecisions.CrystalReports.Engine.Tables CrTables;
                    CrystalDecisions.Shared.ConnectionInfo crConnectionInfo;

                    FolderBrowserDialog fbd = new FolderBrowserDialog();
                    fbd.ShowNewFolderButton = false;

                    OpenFileDialog ofd = new OpenFileDialog();
                    ofd.Multiselect = true;
                    ofd.Filter = "Crystal Report Template (*.RPT)|*.RPT";
                    //ofd.ShowDialog();



                    DialogResult dlgrslt;// = fbd.ShowDialog();

                    dlgrslt = ofd.ShowDialog();
                    if (!(dlgrslt == DialogResult.OK))
                    {
                        return;
                    }

                    //DirectoryInfo d = new DirectoryInfo(sSrcePath);
                    //FileInfo[] files = d.GetFiles("*.rpt"); //Getting rpt files
                    string[] files = ofd.FileNames;


                    dtbAllConnection = new System.Data.DataTable();
                    dtbAllConnection.Columns.Add("Report ID");
                    dtbAllConnection.Columns.Add("Connection");

                    progressBar1.Minimum = 0;
                    progressBar1.Maximum = files.Count();
                    lblReportCount.Text = "Selected Report Count = " + files.Count();
                    int iSubRprtCount;
                    FileInfo f;

                    foreach (string file in files)
                    {
                        f = new FileInfo(file);
                        sRprtIdntfr = f.Name.Replace(".rpt", "");
                        sSrcePath = f.DirectoryName;
                        RptDcmnt = new ReportDocument();
                        drRow = dtbAllConnection.NewRow();

                        try
                        {
                            drRow["Report ID"] = sRprtIdntfr;

                            lblCurrentActivity.Text = "Checking Connection info for : " + sRprtIdntfr;

                            RptDcmnt.Load(sSrcePath + "\\" + sRprtIdntfr + ".rpt");
                            iSubRprtCount = RptDcmnt.Subreports.Count;

                            for (int i = 1; i <= iSubRprtCount; i += 1)
                            {
                                string name = "Sub-Report " + i.ToString() + " Connection";
                                if (!dtbAllConnection.Columns.Contains(name))
                                {
                                    dtbAllConnection.Columns.Add(name, System.Type.GetType("System.String"));
                                }
                            }

                            CrTables = RptDcmnt.Database.Tables;
                            crtableLogoninfo = new TableLogOnInfo();
                            crConnectionInfo = new CrystalDecisions.Shared.ConnectionInfo();



                            foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
                            {

                                crtableLogoninfo = CrTable.LogOnInfo;
                                crConnectionInfo = crtableLogoninfo.ConnectionInfo;
                                //if (crConnectionInfo.ServerName != string.Empty)
                                //{
                                //    drRow["Connection"] = "Yes";
                                //    //MessageBox.Show("For Report " + sRprtIdntfr + " Server name present : " + crConnectionInfo.ServerName);
                                //}

                                if ((crConnectionInfo.UserID != string.Empty) && (crConnectionInfo.UserID != null))
                                {
                                    drRow["Connection"] = "Yes";
                                    //MessageBox.Show("For Report " + sRprtIdntfr + " UserID present : " + crConnectionInfo.UserID);
                                }

                                if ((crConnectionInfo.Password != string.Empty) && (crConnectionInfo.Password != null))
                                {
                                    drRow["Connection"] = "Yes";
                                    //MessageBox.Show("For Report " + sRprtIdntfr + " Password present : " + crConnectionInfo.Password);
                                }

                            }


                            CrTables.Dispose();///////
                            



                            for (int i = 1; i <= iSubRprtCount; i += 1)
                            {
                                rdSubRprt = new ReportDocument();
                                rdSubRprt = RptDcmnt.Subreports[i - 1];

                                string name = "Sub-Report " + i.ToString() + " Connection";

                                CrTables = rdSubRprt.Database.Tables;
                                crtableLogoninfo = new TableLogOnInfo();
                                crConnectionInfo = new CrystalDecisions.Shared.ConnectionInfo();

                                foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
                                {
                                    crtableLogoninfo = CrTable.LogOnInfo;
                                    crConnectionInfo = crtableLogoninfo.ConnectionInfo;
                                    //if (crConnectionInfo.ServerName != string.Empty)
                                    //{
                                    //    drRow[name] = "Yes : " + rdSubRprt.Name.ToString();
                                    //    //MessageBox.Show("For Report : " + sRprtIdntfr + ", Sub-report : " + rdSubRprt.Name+ " Server name present : " + crConnectionInfo.ServerName);
                                    //}

                                    if ((crConnectionInfo.UserID != string.Empty) && (crConnectionInfo.UserID != null))
                                    {
                                        drRow[name] = "Yes : " + rdSubRprt.Name.ToString();
                                        //MessageBox.Show("For Report " + sRprtIdntfr + ", Sub-report : " + rdSubRprt.Name + " UserID present : " + crConnectionInfo.UserID);
                                    }

                                    if ((crConnectionInfo.Password != string.Empty) && (crConnectionInfo.Password != null))
                                    {
                                        drRow[name] = "Yes : " + rdSubRprt.Name.ToString();
                                        //MessageBox.Show("For Report " + sRprtIdntfr + ", Sub-report : " + rdSubRprt.Name + " Password present : " + crConnectionInfo.Password);
                                    }

                                }
                                CrTables.Dispose();///
                                rdSubRprt.Close();
                                rdSubRprt.Dispose();////
                            }


                            RptDcmnt.Close();
                            RptDcmnt.Dispose();
                            progressBar1.Increment(1);
                            dtbAllConnection.Rows.Add(drRow);
                            dataGridView1.DataSource = dtbAllConnection;
                        }
                        catch (Exception ex)
                        {
                            drRow[1] = ex.Message.ToString();
                            dtbAllConnection.Rows.Add(drRow);
                            RptDcmnt.Close();
                            RptDcmnt.Dispose();
                        }
                    }
                    dataGridView1.DataSource = dtbAllConnection;
                    progressBar1.Value = 0;
                    lblCurrentActivity.Text = "Getting Connection Info Complete";
                    btnExport.Visible = false;
                }

          private void getQueries(string sTableNametoCheckInQueries = "")
                {
                    btnExport.Visible = false;
                    lblCurrentActivity.Text = "Extracting Query";
                    System.Data.DataTable dtbAllQueries;
                    DataRow drRow;

                    string sRprtIdntfr;
                    ReportDocument RptDcmnt;
                    ReportDocument rd;
                    string sQuery;


                    //FolderBrowserDialog fbd = new FolderBrowserDialog();
                    //fbd.ShowNewFolderButton = false;
                    dataGridView1.DataSource = null;
                    OpenFileDialog ofd = new OpenFileDialog();
                    ofd.Multiselect = true;
                    ofd.Filter = "Crystal Report Template (*.RPT)|*.RPT";

                    DialogResult dlgrslt = ofd.ShowDialog();
                    if (!(dlgrslt == DialogResult.OK))
                    {
                        return;
                    }

                    //System.Threading.Thread.Sleep(2000);

                    //sSrcePath = fbd.SelectedPath;

                    //DirectoryInfo d = new DirectoryInfo(sSrcePath);
                    //FileInfo[] files = d.GetFiles("*.rpt"); //Getting .rpt files
                    string[] files = ofd.FileNames;
                    FileInfo f;

                    dtbAllQueries = new System.Data.DataTable();
                    dtbAllQueries.Columns.Add("Report ID");
                    dtbAllQueries.Columns.Add("Query");

                    progressBar1.Minimum = 0;
                    progressBar1.Maximum = files.Count();
                    lblReportCount.Text = "Selected Report Count = " + files.Count();

                    foreach (string file in files)
                    {
                        f = new FileInfo(file);
                        sSrcePath = f.DirectoryName;
                        sRprtIdntfr = f.Name.Replace(".rpt", "");

                        RptDcmnt = new ReportDocument();
                        drRow = dtbAllQueries.NewRow();
                        drRow["Report ID"] = sRprtIdntfr;
                        try
                        {
                            lblCurrentActivity.Text = "Extracting Query for : " + sRprtIdntfr;
                            RptDcmnt.Load(sSrcePath + "\\" + sRprtIdntfr + ".rpt");

                            int iSubRprtCnt = RptDcmnt.Subreports.Count;

                            for (int i = 1; i <= iSubRprtCnt; i += 1)
                            {
                                string name = "Sub-Report " + i.ToString() + " Query";
                                if (!dtbAllQueries.Columns.Contains(name))
                                {
                                    dtbAllQueries.Columns.Add(name, System.Type.GetType("System.String"));
                                }
                            }

                            sQuery = getCommandTextRprt(RptDcmnt).ToString();

                            if (sTableNametoCheckInQueries != string.Empty)
                            {
                                drRow["Query"] = sQuery.ToUpper().Contains(sTableNametoCheckInQueries.ToUpper().ToString());
                            }
                            else
                            {
                                drRow["Query"] = sQuery;
                            }


                            //drRow["Query"] = getCommandTextRprt(RptDcmnt).ToString();

                            for (int i = 1; i <= iSubRprtCnt; i += 1)
                            {
                                string name = "Sub-Report " + i.ToString() + " Query";
                                rd = new ReportDocument();
                                rd = RptDcmnt.Subreports[i - 1];
                                sQuery = string.Empty;
                                sQuery = getCommandTextSubRprt(rd);
                                rd.Close();
                                rd.Dispose();///
                                if (sTableNametoCheckInQueries != string.Empty)
                                {
                                    drRow[name] = sQuery.ToUpper().Contains(sTableNametoCheckInQueries.ToUpper().ToString());
                                }
                                else
                                {
                                    drRow[name] = sQuery;
                                }

                                //drRow[name] = getCommandTextSubRprt(rd);
                                //rd.Close();
                            }

                            RptDcmnt.Close();
                            RptDcmnt.Dispose();////
                            progressBar1.Increment(1);
                            dtbAllQueries.Rows.Add(drRow);
                            dataGridView1.DataSource = dtbAllQueries;
                        }
                        catch (Exception ex)
                        {
                            drRow[1] = ex.Message.ToString();
                            dtbAllQueries.Rows.Add(drRow);
                            RptDcmnt.Close();
                            RptDcmnt.Dispose();////
                        }

                    }

                    if (!(dtbAllQueries.Rows.Count > 0))
                    {
                        MessageBox.Show("Nothing fetched");
                        return;
                    }

                    dataGridView1.DataSource = dtbAllQueries;
                    //MessageBox.Show("Completed");
                    progressBar1.Value = 0;
                    lblCurrentActivity.Text = "Query Extraction Done";
                    btnExport.Visible = true;
                }

          public void DataSetsToExcel(List<System.Data.DataSet> dataSets, string fileName)
          {
              try
              {
                  Microsoft.Office.Interop.Excel.Application xlApp =
                            new Microsoft.Office.Interop.Excel.Application();
                  Workbook xlWorkbook = xlApp.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
                  Sheets xlSheets = null;
                  Worksheet xlWorksheet = null;

                  foreach (System.Data.DataSet dataSet in dataSets)
                  {
                      System.Data.DataTable dataTable = dataSet.Tables[0];
                      int rowNo = dataTable.Rows.Count;
                      int columnNo = dataTable.Columns.Count;
                      int colIndex = 0;

                      //Create Excel Sheets
                      xlSheets = xlWorkbook.Sheets;
                      xlWorksheet = (Worksheet)xlSheets.Add(xlSheets[1],
                                     Type.Missing, Type.Missing, Type.Missing);
                      xlWorksheet.Name = dataSet.DataSetName;

                      //Generate Field Names
                      foreach (DataColumn dataColumn in dataTable.Columns)
                      {
                          colIndex++;
                          xlApp.Cells[1, colIndex] = dataColumn.ColumnName;

                      }

                      object[,] objData = new object[rowNo, columnNo];

                      //Convert DataSet to Cell Data
                      for (int row = 0; row < rowNo; row++)
                      {
                          for (int col = 0; col < columnNo; col++)
                          {
                              objData[row, col] = dataTable.Rows[row][col];
                          }
                      }

                      //Add the Data
                      Range range = xlWorksheet.Range[xlApp.Cells[2, 1], xlApp.Cells[rowNo + 1, columnNo]];
                      //Range range = xlWorksheet.Range[xlApp.Cells[2, 1], xlApp.Cells[rowNo, columnNo]];
                      range.Value2 = objData;

                      //Format Data Type of Columns 
                      colIndex = 0;
                      foreach (DataColumn dataColumn in dataTable.Columns)
                      {
                          colIndex++;
                          string format = "@";
                          switch (dataColumn.DataType.Name)
                          {
                              case "Boolean":
                                  break;
                              case "Byte":
                                  break;
                              case "Char":
                                  break;
                              case "DateTime":
                                  format = "dd-MMM-yyyy";
                                  break;
                              case "Decimal":
                                  format = "###;[Red]-$* #,##0.00";
                                  break;
                              case "Double":
                                  break;
                              case "Int16":
                                  format = "0";
                                  break;
                              case "Int32":
                                  format = "0";
                                  break;
                              case "Int64":
                                  format = "0";
                                  break;
                              case "SByte":
                                  break;
                              case "Single":
                                  break;
                              case "TimeSpan":
                                  break;
                              case "UInt16":
                                  break;
                              case "UInt32":
                                  break;
                              case "UInt64":
                                  break;
                              default: //String
                                  break;
                          }
                          //Format the Column accodring to Data Type
                          xlWorksheet.Range[xlApp.Cells[2, colIndex],
                                xlApp.Cells[rowNo + 1, colIndex]].NumberFormat = format;
                      }
                  }

                  //Remove the Default Worksheet
                  ((Worksheet)xlApp.ActiveWorkbook.Sheets[xlApp.ActiveWorkbook.Sheets.Count]).Delete();

                  //Save
                  xlWorkbook.SaveAs(fileName,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value,
                      XlSaveAsAccessMode.xlNoChange,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value,
                      System.Reflection.Missing.Value);

                  xlWorkbook.Close();
                  xlApp.Quit();
                  GC.Collect();
              }
              catch (Exception ex)
              {
                  MessageBox.Show(ex.Message);
                  MessageBox.Show("unable to generate excel");
              }
          }

        # endregion

        # region FormActivity

            private void Form1_Load(object sender, EventArgs e)
                {
                    radioChkConnString.Checked = true;
                    btnExport.Visible = false;
                    //label1.Visible = false;
                    //label4.Visible = false;
                }

            private void btnExport_Click(object sender, EventArgs e)
                {

                    lblCurrentActivity.Text = "Exporting Excel";
                    try
                    {

                        System.Data.DataSet ds1 = new System.Data.DataSet("Report Queries");
                        //ds1 = (System.Data.DataTable)dataGridView1.DataSource;
                        System.Data.DataTable dtbGridTable = (System.Data.DataTable)dataGridView1.DataSource;
                        if (!(dtbGridTable.Rows.Count > 0))
                        {
                            return;
                        }
                        ds1.Tables.Add(dtbGridTable);
                        List<System.Data.DataSet> dataSets = new List<System.Data.DataSet>();
                        dataSets.Add(ds1);
                        string fname = sSrcePath + "\\" + "Report Queries";
                        DataSetsToExcel(dataSets, fname);
                        lblCurrentActivity.Text = "Exporting Excel Completed";
                        MessageBox.Show("Exported Excel to the below path " + Environment.NewLine + fname + ".xlsx");
                    }
                    catch (Exception ex)
                    {
                        lblCurrentActivity.Text = "Exporting Excel Failed";
                    }
                }

            private void radioChkConnString_CheckedChanged(object sender, EventArgs e)
                {
                    if (radioChkConnString.Checked == true)
                    {
                        txtTableName.Clear();
                        lblReportCount.Text = string.Empty;
                        lblCurrentActivity.Text = string.Empty;
                        dataGridView1.DataSource = null;
                        btnExport.Visible = false;
                        btnAction.Text = "Check Connection String Present in rpt";
                    }
                }

            private void radioFindTables_CheckedChanged(object sender, EventArgs e)
                {
                    if (radioFindTables.Checked == true)
                    {
                        txtTableName.Clear();
                        lblReportCount.Text = string.Empty;
                        lblCurrentActivity.Text = string.Empty;
                        dataGridView1.DataSource = null;
                        btnExport.Visible = false;
                        btnAction.Text = "Find if table used in rpt";
                    }
                }

            private void radioGetAllQueries_CheckedChanged(object sender, EventArgs e)
                {

                    if (radioGetAllQueries.Checked == true)
                    {
                        txtTableName.Clear();
                        lblReportCount.Text = string.Empty;
                        lblCurrentActivity.Text = string.Empty;
                        dataGridView1.DataSource = null;
                        btnExport.Visible = false;
                        btnAction.Text = "Get All Queries from rpt";
                    }
                }

            private void btnAction_Click(object sender, EventArgs e)
                {
                    dataGridView1.DataSource = null;
                    if (radioChkConnString.Checked == true)
                    {
                        chkConnections();
                    }

                    else if (radioFindTables.Checked == true)
                    {
                        string sTableName = txtTableName.Text.Trim();

                        if (String.IsNullOrEmpty(sTableName))
                        {
                            MessageBox.Show("Please enter table name to search");
                        }
                        else
                        {
                            getQueries(sTableName);
                        }
                    }

                    else if (radioGetAllQueries.Checked == true)
                    {
                        getQueries();
                    }

                }

        # endregion

         

        //private void btnChkConn_Click(object sender, EventArgs e)
        //{
        //    btnExport.Visible = false;
        //    lblCurrentActivity.Text = "Connection info ";

        //    System.Data.DataTable dtbAllConnection;
        //    DataRow drRow;
        //    dataGridView1.DataSource = null;
        //    string sRprtIdntfr;

        //    ReportDocument RptDcmnt;
        //    ReportDocument rdSubRprt;
        //    TableLogOnInfo crtableLogoninfo;
        //    CrystalDecisions.CrystalReports.Engine.Tables CrTables;
        //    CrystalDecisions.Shared.ConnectionInfo crConnectionInfo;

        //    FolderBrowserDialog fbd = new FolderBrowserDialog();
        //    fbd.ShowNewFolderButton = false;

        //    OpenFileDialog ofd = new OpenFileDialog();
        //    ofd.Multiselect = true;
        //    ofd.Filter = "Crystal Report Template (*.RPT)|*.RPT";
        //    //ofd.ShowDialog();

            
 
        //    DialogResult dlgrslt;// = fbd.ShowDialog();

        //    dlgrslt = ofd.ShowDialog();
        //    if (!(dlgrslt == DialogResult.OK))
        //    {
        //        return;
        //    }

            
            




        //    //DirectoryInfo d = new DirectoryInfo(sSrcePath);
        //    //FileInfo[] files = d.GetFiles("*.rpt"); //Getting rpt files
        //    string[] files = ofd.FileNames;


        //    dtbAllConnection = new System.Data.DataTable();
        //    dtbAllConnection.Columns.Add("Report ID");
        //    dtbAllConnection.Columns.Add("Connection");

        //    progressBar1.Minimum = 0;
        //    progressBar1.Maximum = files.Count();
        //    lblReportCount.Text = "Total Reports = " + files.Count();
        //    int iSubRprtCount;
        //    FileInfo f;

        //    foreach (string file in files)
        //    {
        //        f = new FileInfo(file);
        //        sRprtIdntfr = f.Name.Replace(".rpt", "");
        //        sSrcePath = f.DirectoryName;
        //        RptDcmnt = new ReportDocument();
        //        drRow = dtbAllConnection.NewRow();

        //        try
        //        {
        //            drRow["Report ID"] = sRprtIdntfr;

        //            lblCurrentActivity.Text = "Checking Connection info for : " + sRprtIdntfr;

        //            RptDcmnt.Load(sSrcePath + "\\" + sRprtIdntfr + ".rpt");
        //            iSubRprtCount = RptDcmnt.Subreports.Count;

        //            for (int i = 1; i <= iSubRprtCount; i += 1)
        //            {
        //                string name = "Sub-Report " + i.ToString() + " Connection";
        //                if (!dtbAllConnection.Columns.Contains(name))
        //                {
        //                    dtbAllConnection.Columns.Add(name, System.Type.GetType("System.String"));
        //                }
        //            }

        //            CrTables = RptDcmnt.Database.Tables;
        //            crtableLogoninfo = new TableLogOnInfo();
        //            crConnectionInfo = new CrystalDecisions.Shared.ConnectionInfo();



        //            foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
        //            {

        //                crtableLogoninfo = CrTable.LogOnInfo;
        //                crConnectionInfo = crtableLogoninfo.ConnectionInfo;
        //                //if (crConnectionInfo.ServerName != string.Empty)
        //                //{
        //                //    drRow["Connection"] = "Yes";
        //                //    //MessageBox.Show("For Report " + sRprtIdntfr + " Server name present : " + crConnectionInfo.ServerName);
        //                //}

        //                if ((crConnectionInfo.UserID != string.Empty) && (crConnectionInfo.UserID != null))
        //                {
        //                    drRow["Connection"] = "Yes";
        //                    //MessageBox.Show("For Report " + sRprtIdntfr + " UserID present : " + crConnectionInfo.UserID);
        //                }

        //                if ((crConnectionInfo.Password != string.Empty) && (crConnectionInfo.Password != null))
        //                {
        //                    drRow["Connection"] = "Yes";
        //                    //MessageBox.Show("For Report " + sRprtIdntfr + " Password present : " + crConnectionInfo.Password);
        //                }

        //            }

        //            for (int i = 1; i <= iSubRprtCount; i += 1)
        //            {
        //                rdSubRprt = new ReportDocument();
        //                rdSubRprt = RptDcmnt.Subreports[i - 1];

        //                string name = "Sub-Report " + i.ToString() + " Connection";

        //                CrTables = rdSubRprt.Database.Tables;
        //                crtableLogoninfo = new TableLogOnInfo();
        //                crConnectionInfo = new CrystalDecisions.Shared.ConnectionInfo();

        //                foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
        //                {
        //                    crtableLogoninfo = CrTable.LogOnInfo;
        //                    crConnectionInfo = crtableLogoninfo.ConnectionInfo;
        //                    //if (crConnectionInfo.ServerName != string.Empty)
        //                    //{
        //                    //    drRow[name] = "Yes : " + rdSubRprt.Name.ToString();
        //                    //    //MessageBox.Show("For Report : " + sRprtIdntfr + ", Sub-report : " + rdSubRprt.Name+ " Server name present : " + crConnectionInfo.ServerName);
        //                    //}

        //                    if ((crConnectionInfo.UserID != string.Empty) && (crConnectionInfo.UserID != null))
        //                    {
        //                        drRow[name] = "Yes : " + rdSubRprt.Name.ToString();
        //                        //MessageBox.Show("For Report " + sRprtIdntfr + ", Sub-report : " + rdSubRprt.Name + " UserID present : " + crConnectionInfo.UserID);
        //                    }

        //                    if ((crConnectionInfo.Password != string.Empty) && (crConnectionInfo.Password != null))
        //                    {
        //                        drRow[name] = "Yes : " + rdSubRprt.Name.ToString();
        //                        //MessageBox.Show("For Report " + sRprtIdntfr + ", Sub-report : " + rdSubRprt.Name + " Password present : " + crConnectionInfo.Password);
        //                    }

        //                }

        //                rdSubRprt.Close();
        //            }


        //            RptDcmnt.Close();
        //            progressBar1.Increment(1);
        //            dtbAllConnection.Rows.Add(drRow);
        //        }
        //        catch (Exception ex)
        //        {
        //            dtbAllConnection.Rows.Add(drRow);
        //            RptDcmnt.Close();
        //        }
        //    }
        //    dataGridView1.DataSource = dtbAllConnection;
        //    progressBar1.Value = 0;
        //    lblCurrentActivity.Text = "Getting Connection Info Complete";
        //    btnExport.Visible = false;
        //}

        //private void btnGet_Click(object sender, EventArgs e)
        //{
        //    btnExport.Visible = false;
        //    lblCurrentActivity.Text = "Extracting Query";
        //    System.Data.DataTable dtbAllQueries;
        //    DataRow drRow;

        //    string sRprtIdntfr;
        //    ReportDocument RptDcmnt;
        //    ReportDocument rd;

        //    //FolderBrowserDialog fbd = new FolderBrowserDialog();
        //    //fbd.ShowNewFolderButton = false;
        //    dataGridView1.DataSource = null;
        //    OpenFileDialog ofd = new OpenFileDialog();
        //    ofd.Multiselect = true;
        //    ofd.Filter = "Crystal Report Template (*.RPT)|*.RPT";

        //    DialogResult dlgrslt = ofd.ShowDialog();
        //    if (!(dlgrslt == DialogResult.OK))
        //    {
        //        return;
        //    }

        //    //System.Threading.Thread.Sleep(2000);

        //    //sSrcePath = fbd.SelectedPath;

        //    //DirectoryInfo d = new DirectoryInfo(sSrcePath);
        //    //FileInfo[] files = d.GetFiles("*.rpt"); //Getting .rpt files
        //    string[] files = ofd.FileNames;
        //    FileInfo f;

        //    dtbAllQueries = new System.Data.DataTable();
        //    dtbAllQueries.Columns.Add("Report ID");
        //    dtbAllQueries.Columns.Add("Query");

        //    progressBar1.Minimum = 0;
        //    progressBar1.Maximum = files.Count();
        //    lblReportCount.Text = "Total Reports = " + files.Count();

        //    foreach (string file in files)
        //    {
        //        f = new FileInfo(file);
        //        sSrcePath = f.DirectoryName;
        //        sRprtIdntfr = f.Name.Replace(".rpt", "");

        //        RptDcmnt = new ReportDocument();
        //        drRow = dtbAllQueries.NewRow();
        //        drRow["Report ID"] = sRprtIdntfr;
        //        try
        //        {
        //            lblCurrentActivity.Text = "Extracting Query for : " + sRprtIdntfr;
        //            RptDcmnt.Load(sSrcePath + "\\" + sRprtIdntfr + ".rpt");

        //            int iSubRprtCnt = RptDcmnt.Subreports.Count;

        //            for (int i = 1; i <= iSubRprtCnt; i += 1)
        //            {
        //                string name = "Sub-Report " + i.ToString() + " Query";
        //                if (!dtbAllQueries.Columns.Contains(name))
        //                {
        //                    dtbAllQueries.Columns.Add(name, System.Type.GetType("System.String"));
        //                }
        //            }

        //            drRow["Query"] = getCommandTextRprt(RptDcmnt);

        //            for (int i = 1; i <= iSubRprtCnt; i += 1)
        //            {
        //                string name = "Sub-Report " + i.ToString() + " Query";
        //                rd = new ReportDocument();
        //                rd = RptDcmnt.Subreports[i - 1];
        //                drRow[name] = getCommandTextSubRprt(rd);
        //                rd.Close();
        //            }

        //            RptDcmnt.Close();
        //            progressBar1.Increment(1);
        //            dtbAllQueries.Rows.Add(drRow);
        //        }
        //        catch (Exception ex)
        //        {
        //            dtbAllQueries.Rows.Add(drRow);
        //            RptDcmnt.Close();
        //        }

        //    }

        //    if (!(dtbAllQueries.Rows.Count > 0))
        //    {
        //        MessageBox.Show("Nothing fetched");
        //        return;
        //    }

        //    dataGridView1.DataSource = dtbAllQueries;
        //    //MessageBox.Show("Completed");
        //    progressBar1.Value = 0;
        //    lblCurrentActivity.Text = "Query Extraction Done";
        //    btnExport.Visible = true;
        //}
        
    }
}
